#!/bin/bash

#get user input to ensure version number is correct

echo "Please enter the version number (e.g 10.0.6) for your installation of Live and press [ENTER] on your keyboard. You can find the version number on your Ableton.com account page under the main Licenses heading"

read VERSION

echo "Thanks. We'll create the necessary files and folders to ensure Live $VERSION is authorized for all users on this machine"

osascript -e 'tell app "System Events" to display dialog "Thanks. Now press OK and and enter your admin password into the terminal window"'

#copy unlock.cfg back to USB stick after authorization

parent_path=$( cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P )

cd "$parent_path"

if [ -f Unlock.cfg ]

then

	sudo rm Unlock.cfg
fi

sudo cp /Users/$USER/Library/Application\ Support/Ableton/Live\ $VERSION/Unlock/Unlock.cfg "$parent_path"

if [ ! -f ./Unlock.cfg ]

then

	osascript -e 'tell app "System Events" to display dialog "The master unlock file could not be copied back to the USB folder. Please contact Ableton Technical Support at support@ableton.com"'
fi

#copy unlock.cfg from default location on admin account to shared location


sudo mkdir -p /Library/Application\ Support/Ableton/Live\ $VERSION/Unlock/

echo "Shared unlock folder created"

sudo cp /Users/$USER/Library/Application\ Support/Ableton/Live\ $VERSION/Unlock/Unlock.cfg /Library/Application\ Support/Ableton/Live\ $VERSION/Unlock/

echo "Copied Unlock.cfg from default location to shared location"

if [ ! -f /Library/Application\ Support/Ableton/Live\ $VERSION/Unlock/Unlock.cfg ]

then

	osascript -e 'tell app "System Events" to display dialog "The master unlock file could not be copied to the shared location. Please contact Ableton Technical Support at support@ableton.com"'
fi

#copy the shared unlock file to all user accounts

USERLIST=`ls /Users | grep -v 'Shared' | grep -v -i '.localized'`

for u in $USERLIST ; do
	echo "Copying Unlock.cfg to " $u

	sudo cp /Library/Application\ Support/Ableton/Live\ $VERSION/Unlock/Unlock.cfg /Users/$u/Library/Application\ Support/Ableton/Live\ $VERSION/Unlock/
done

#create a shared preferences folder

sudo mkdir -p /Library/Preferences/Ableton/Live\ $VERSION/

echo "created shared preferences folder"

if [ ! -d /Library/Preferences/Ableton/Live\ $VERSION/ ]

then
	osascript -e 'tell app "System Events" to display dialog "The shared Preferences folder could not be created. Please contact Ableton Technical Support at support@ableton.com"'
fi

#create Options.txt with appropriate options

echo "-_DisableAutoUpdates" | sudo tee /Library/Preferences/Ableton/Live\ $VERSION/Options.txt

echo "created Options.txt file"

echo "added Option -_DisableAutoUpdates"

# excluding the creation of "shared" database / caches folders until further testing is done on these options

#echo "-DefaultsBaseFolder=/tmp/AbletonData/%%USERNAME%%/" | sudo tee -a /Library/Preferences/Ableton/Live\ $VERSION/Options.txt

#echo "added option -DefaultsBaseFolder"

#echo "-DatabaseDirectory=/Users/Shared/Database/%%USERNAME%%/" | sudo tee -a /Library/Preferences/Ableton/Live\ $VERSION/Options.txt

#echo "added option -DatabaseDirectory"

echo "-DontAskForAdminRights" | sudo tee -a /Library/Preferences/Ableton/Live\ $VERSION/Options.txt

echo "added option -DontAskForAdminRights"

#create shared packs folder

sudo mkdir -p /Library/Audio/Ableton/Factory\ Packs

echo "created shared Packs folder at /Library/Audio/Ableton/Factory Packs"

if [ ! -d /Library/Audio/Ableton/Factory\ Packs ]

then
	osascript -e 'tell app "System Events" to display dialog "The shared Packs folder could not be created. Please contact Ableton Technical Support at support@ableton.com"'
fi

#edit Library.cfg to point Packs and User Library to shared location // excluding for now as it's optional and can easily be done manually by each user

#move Library.cfg to shared location

#sudo cp /Users/$USER/Library/Preferences/Ableton/Live\ $VERSION/Library.cfg /Library/Preferences/Ableton/Live\ $VERSION/

#echo "moved Library.cfg to shared location"


#sudo cat /Library/Preferences/Ableton/Live\ $VERSION/Library.cfg | sed "s:/Users/$USER/Music/Ableton/:/Users/%%USERNAME%%/Music/Ableton/:" | sudo tee /Library/Preferences/Ableton/Live\ $VERSION/Library.cfg

#sudo cat /Library/Preferences/Ableton/Live\ $VERSION/Library.cfg | sed "s:/Users/%%USERNAME%%/Music/Ableton/User Library:/Users/$USER/Music/Ableton/User Library:" | sudo tee /Library/Preferences/Ableton/Live\ $VERSION/Library.cfg

#echo "successfully modified Library.cfg"

#copy Options.txt to all existing user accounts

for u in $USERLIST ; do
	echo "Copying Options.txt to " $u

	#sudo cp /Library/Preferences/Ableton/Live\ $VERSION/Library.cfg /Users/$u/Library/Preferences/Ableton/Live\ $VERSION/ //excluding re: note above about it being optional

	sudo cp /Library/Preferences/Ableton/Live\ $VERSION/Options.txt /Users/$u/Library/Preferences/Ableton/Live\ $VERSION/

done

echo "Live should now be authorized for all users on this machine. Have fun!"

osascript -e 'tell app "System Events" to display dialog "Live should now be authorized for all users on this machine. Please refer to the included Readme.txt for the location of the shared Packs folder. Have fun!"'